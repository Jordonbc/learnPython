import sys

from PyQt4.QtWebKit import QWebView
from PyQt4.QtGui import QApplication
from PyQt4.QtCore import QUrl
from PyQt4 import QtGui
from PyQt4.QtGui import QLineEdit
from PyQt4 import QtCore
import requests
import os
import pickle
import gi.repository
gi.require_version('Soup', '2.4')
import gi.repository.Soup

try:
    b = open("bookmarks.txt", "rb")
    bookmarks = pickle.loads(b.read())
    b.close()
except:
    bookmarks = []

import tagFinder # My own tag finder

app = QApplication(sys.argv)

frame = QtGui.QFrame()
# frame.setTitle("TEST")

layout = QtGui.QVBoxLayout()

frame.setLayout(layout)

address = "https://www.google.co.uk"

getData = tagFinder.findData(address)

def Bookmark():
    global address
    global bookmarks

    https = "https://"
    http = "http://"

    if str(address).replace(http, "").replace(https, "") not in bookmarks:
        bookmarks.append(str(address).replace(http, "").replace(https, ""))
        list.addItem(str(address).replace(http, "").replace(https, ""))
        book.setText("★")
    else:
        list.removeItem(bookmarks.index(str(address).replace(http, "").replace(https, "")))
        bookmarks.remove(str(address).replace(http, "").replace(https, ""))
        book.setText("☆")

    b = open("bookmarks.txt", "wb")
    pickle.dump(bookmarks, b)
    b.close()


def handleBookmarks(choice):
    global address
    global e4

    address = choice
    e4.setText(address)
    textchanged()

list = QtGui.QComboBox()
list.setMinimumSize(160, 30)

https = "https://"
http = "http://"

for i in bookmarks:
    list.addItem(str(i).replace(http, "").replace(https, ""))

list.activated[str].connect(handleBookmarks)
list.view().setSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Minimum)


def timeout():
    global oldAddress
    frame.setWindowTitle("Unable to load page! - Jordon's Online Browser")
    e4.setText(oldAddress)
    browser.load(QUrl("error.html"))

def back():
    global browser
    global book
    browser.back()
    if str(address).replace(http, "").replace(https, "") in bookmarks:
        book.setText("★")

    else:
        book.setText("☆")

def forward():
    global browser
    global book
    browser.forward()
    if str(address).replace(http, "").replace(https, "") in bookmarks:
        book.setText("★")

    else:
        book.setText("☆")

def reload():
    global browser
    global book
    browser.reload()
    if str(address).replace(http, "").replace(https, "") in bookmarks:
        book.setText("★")

    else:
        book.setText("☆")


def textchanged():
    global oldAddress
    global address
    global title
    global book
    global e4

    address = e4.text()

    https = "https://"
    http = "http://"
    www = "www."

    if www in address and http not in address or www in address and https not in address:
        address = http + address
    elif "." not in address:
        address = "http://www.google.com/search?q=" + address

    elif http in address and www not in address:
        address = address[:7] + www + address[7:]

    elif https not in address or http not in address:
        address = http + address

    try:
        getData.new(address)
        title = str(getData.title)
    except:
        pass

    print(str(address).replace(http, "").replace(https, ""))

    if str(address).replace(http, "").replace(https, "") in bookmarks:
        book.setText("★")

    else:
        book.setText("☆")

    try:
        request = requests.get(address)
        if request.status_code == 200:
            print('Web site exists')
            e4.setText(address)
            frame.setWindowTitle(title + " - Jordon's Online Browser")
            browser.load(QUrl(address))
        else:
            print('Web site does not exist')
            oldAddress = address
            e4.setText(address)
            frame.setWindowTitle(title + " - Jordon's Online Browser")

            timeout()
    except Exception as e:
        print(str(e))


def pagechanged():
    global address
    global title
    global book
    address = QUrl(browser.url()).toString()
    try:
        getData.new(address)
        title = getData.title
    except:
        pass
    e4.setText(address)
    frame.setWindowTitle(title + " - Jordon's Online Browser")
    if str(address).replace(http, "").replace(https, "") in bookmarks:
        book.setText("★")

    else:
        book.setText("☆")


palette = QtGui.QPalette()

palette.setColor(QtGui.QPalette.Background, QtCore.Qt.red)

e4 = QLineEdit()
e4.setMinimumSize(200, 30)

e4.setAutoFillBackground(True)

e4.setPalette(palette)

# e4.keyPressEvent(press)
# e4.setStyleSheet("background: red;")

e4.returnPressed.connect(textchanged)

buttonLayout = QtGui.QHBoxLayout()

reloadButton = QtGui.QPushButton()

reloadButton.setText("↻")
reloadButton.setMaximumSize(35, 30)

reloadButton.setPalette(palette)

reloadButton.pressed.connect(reload)

backButton = QtGui.QPushButton()

backButton.setText("←")
backButton.setMaximumSize(35, 30)

backButton.setPalette(palette)

backButton.pressed.connect(back)

forwardButton = QtGui.QPushButton()

forwardButton.setText("→")
forwardButton.setMaximumSize(35, 30)

forwardButton.setPalette(palette)

forwardButton.pressed.connect(forward)

book = QtGui.QPushButton("☆")
book.setMaximumSize(35, 30)
book.pressed.connect(Bookmark)
book.setStyleSheet("font-size:18px;")

buttonLayout.addWidget(book)
buttonLayout.addWidget(backButton)
buttonLayout.addWidget(reloadButton)
buttonLayout.addWidget(forwardButton)
buttonLayout.addWidget(e4)
buttonLayout.addWidget(list)




# layout.addWidget(e4)
layout.addLayout(buttonLayout)

title = getData.title

browser = QWebView()
e4.setText(address)
browser.load(QUrl(address))

browser.urlChanged.connect(pagechanged)

settings = browser.settings()

settings.DnsPrefetchEnabled = True
settings.enablePersistentStorage("storage/")
settings.JavaEnabled = True
settings.setLocalStoragePath("storage/")
settings.LocalStorageEnabled = True
settings.LocalStorageDatabaseEnabled = True
settings.WebGLEnabled = True
settings.PluginsEnabled = True
settings.OfflineWebApplicationCacheEnabled = True
settings.enable_java_applet = True
settings.enable_page_cache = True
settings.enable_html5_local_storage = True
settings.enable_html5_database = True
settings.AcceleratedCompositingEnabled = True

browser.setUpdatesEnabled(True)

# browser.setLayout(flo)


frame.setWindowTitle(address + " - Jordon's Online Browser")

browser.show()

layout.addWidget(browser)

frame.show()

app.exec_()

os.remove("tmp")
sys.exit()
