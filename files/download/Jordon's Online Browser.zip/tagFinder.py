import urllib.request
class findData:
    def new(self, content):
        self.__init__(content)
    def custom(self, start, end):
        def removeBlank(tags):
            for data in tags:
                if data == "" or data == " ":
                    tags.remove(data)
            return tags
        def process(start, end):
            return removeBlank(
                str(self.everything_between(str("<" + start + ">"), str("</" + end + ">"))).replace("		",
                                                                                                  "").replace("    ",
                                                                                                              "").split(
                    "   "))
        return process(start, end)

    def everything_between(self, begin, end):
        idx1 = self.content.find(begin)
        idx2 = self.content.find(end, idx1)
        return self.content[idx1 + len(begin):idx2].strip()

    def __init__(self, content):
        self.content = content

        file = open("tmp", "w")
        file.close()

        with urllib.request.urlopen(content) as f:
            a = open("tmp", "w")
            a.write(str(f.read()))
            a.close()

        b = open("tmp", "r")
        self.content = b.read()
        b.close()

        self.title = str(self.everything_between("<title>", "</title>"))

        def process(tag):
            return removeBlank(
                str(self.everything_between(str("<" + tag + ">"), str("</" + tag + ">"))).replace("		",
                                                                                                  "").replace("    ",
                                                                                                              "").split(
                    "   "))

        def removeBlank(tags):
            for data in tags:
                if data == "" or data == " ":
                    tags.remove(data)
            return tags

        self.body = process("body")

        self.head = process("head")

        self.div = process("div")

        self.p = process("p")
