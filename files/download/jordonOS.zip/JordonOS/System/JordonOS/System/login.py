#################################################################################
#                                   LOGIN SCRIPT
def login_code():
    import tkinter
    import getpass
    import base64
    import jordonOS
    import time
    from jordonOS import interface
    global permission
    global nick
    global username
    nick="JordonOS"
    username = nick
    ####################################
#                                   ACCOUNTS LIST
    global user_account
    global jordonOS_account
    global jordon_account
    global guest_account
    jordonOS_account=["am9yZG9uT1M=","am9yZG9uT1M="]
    jordon_account=["am9yZG9u","dGVzdDEyMw=="]
    guest_account=["Z3Vlc3Q=",""]
    user_account="none"

    user_1=jordon_account[0]
    user_1=base64.b64decode(user_1)
    user_1=str(user_1).replace("b","").replace("'","")
    user_2=guest_account[0]
    user_2=base64.b64decode(user_2)
    user_2=str(user_2).replace("b","").replace("'","")
    user_3=jordonOS_account[0]
    user_3=base64.b64decode(user_3)
    user_3=str(user_3).replace("b","").replace("'","")
    ####################################
    #               Tkinter
    def login():
        #name=input("Please enter your name: ")
        #file = open("System/Users/" + name.lower() + "_profile.txt", "r")
        window = tkinter.Tk()
        window.title("JordonOS Login")
        window.geometry("350x250")
        window.wm_iconbitmap("System/JordonOS Logo.ico")
        window.configure(bg="#39d972")
        def callback(event):
            global name
            name = profile.get()
            try:
                file = open("System/Users/" + name.lower() + "_profile.txt", "r")
                file.close()
            except:
                message.configure(text = "Err: Profile does not exist!")
            file = open("System/Users/" + name.lower() + "_profile.txt", "r")
            global line
            line = file.readlines()
            global username
            username = user.get()

            global password
            password = passw.get()
            if username == line[1].strip() and password == line[2].strip():
                message.configure(text = "Logged in.")
                print("Login Successful!")
                time.sleep(3)
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                nick=open("nick.file","w")
                nick.write(username)
                nick.close()
                user_account=open("login.file","w")
                user_account.write(line[3])
                user_account.close()
                window.destroy()
                global user_dir
                user_dir = line[4]
                print(user_dir)
                interface()
            else:
                message.configure(text="Err: Username and password don't match the profile")
        title1 = tkinter.Label(window, text="Login to JordonOS\n", bg="#39d972")
        profile_title = tkinter.Label(window, text="---Profile---", bg="#39d972")
        profile = tkinter.Entry(window)
        usertitle = tkinter.Label(window, text="---Username---", bg="#39d972")
        passtitle = tkinter.Label(window, text="---Password---", bg="#39d972")
        message = tkinter.Label(window, bg="#39d972")
        user = tkinter.Entry(window)
        passw = tkinter.Entry(window, show='*')
        go = tkinter.Button(window, text="Log in!", bg="#93ff00")

        title1.pack()
        profile_title.pack()
        profile.pack()
        usertitle.pack()
        user.pack()
        passtitle.pack()
        passw.pack()
        go.pack()
        message.pack()
        go.focus()
        go.bind("<Button-1>", callback)
        go.bind("<Return>", callback)

        window.mainloop()
    login()
    ####################################
    print("Login to continue...")
    print("'jordon' or 'guest'")
    username=input("Username=")
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
    print("(Not required if 'guest' account is used)")
    password=input("Password=")
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
    user_1=jordon_account[0]
    user_1=base64.b64decode(user_1)
    user_1=str(user_1).replace("b","").replace("'","")
    user_2=guest_account[0]
    user_2=base64.b64decode(user_2)
    user_2=str(user_2).replace("b","").replace("'","")
    user_3=jordonOS_account[0]
    user_3=base64.b64decode(user_3)
    user_3=str(user_3).replace("b","").replace("'","")
################################################
#                                   LOGIN CHECKER
    if username==user_2:
        user_account=open("login.file","w")
        #owner=2,admin=1,none=0
        user_account.write("0")
        user_account.close()
        nick=open("nick.file","w")
        nick.write("Guest")
        nick.close()
        print("\n")
        print("Login Successful!")
        time.sleep(3)
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
        interface()
    ###############################
    if username==user_1:
        user_account=open("login.file","w")
        #owner=2,admin=1,none=0
        user_account.write("1")
        user_account.close()
        username_status=1
        predicted_pass=jordon_account[1]
        predicted_pass=base64.b64decode(predicted_pass)
        predicted_pass=str(predicted_pass).replace("b","").replace("'","")
        if password==predicted_pass:
            password_status=1
            print("\n")
            print("Login Successful!")
            time.sleep(3)
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            nick=open("nick.file","w")
            nick.write("Jordon")
            nick.close()
            interface()
        else:
            print("\n")
            print("Login Incorrect!")
            login_code()
################################################
    if username==user_3:
        user_account=open("login.file","w")
        #owner=2,admin=1,none=0
        user_account.write("2")
        user_account.close()
        username_status=1
        predicted_pass=jordonOS_account[1]
        predicted_pass=base64.b64decode(predicted_pass)
        predicted_pass=str(predicted_pass).replace("b","").replace("'","")
        if password==predicted_pass:
            password_status=1
            print("\n")
            print("Login Successful!")
            time.sleep(3)
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            nick=open("nick.file","w")
            nick.write("JordonOS")
            nick.close()
            interface()
        else:
            print("\n")
            print("Login Incorrect!")
            time.sleep(3)
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            login_code()
    else:
        print("\n")
        print("Login Incorrect!")
        time.sleep(3)
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
        login_code()
