################################################################################
#                               SHUTDOWN SCRIPT
def shutdown_code():
    import time
    print("JordonOS will now shutdown please wait...")
    print("Saving components...")
    print("shutting down...")
    exit()