##########################################################################
#                             STARTUP SCRIPT
def startup_code():
    import jordonOS
    from jordonOS import start
    import shutdown
    global user

    start()
startup_code()
