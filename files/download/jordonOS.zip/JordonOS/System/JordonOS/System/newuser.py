from tkinter import *
import os
def newuser_code():
        #name=input("Please enter your name: ")
        #file = open("System/Users/" + name.lower() + "_profile.txt", "r")

        window = Tk()
        window.title("JordonOS New User")
        window.geometry("350x250")
        window.wm_iconbitmap("System/JordonOS Logo.ico")
        window.configure(bg="#39d972")
        def callback():
            name = profile.get()
            user_dir = "Users/"+name
            perm = permission.get()

            file = open("System/Users/" + name.lower() + "_profile.txt", "a")
            global username
            username = user.get()

            password = passw.get()
            password2 = passw1.get()
            if password == password2:
                if perm == "0" or perm == "1" or perm == "2":
                    if not os.path.exists(user_dir):
                        os.makedirs(user_dir)
                        if not os.path.exists(user_dir+"/Documents"):
                            os.makedirs(user_dir+"/Documents")
                    file.write("--==")
                    file.write(name)
                    file.write("==--")
                    file.write("\n")
                    file.write(username)
                    file.write("\n")
                    file.write(password)
                    file.write("\n")
                    file.write(perm)
                    file.write("\n")
                    file.write(user_dir)

                    message.configure(text = "Account Successfully Created!")
                    window.destroy()
                else:
                    message.configure(text="Err: Permission is not 0, 1 or 2!")
            else:
                message.configure(text="Err: passwords do not match!")


        title1 = Label(window, text="Add an account to jordonOS\n", bg="#39d972")
        profile_title = Label(window, text="---Profile---", bg="#39d972")
        profile = Entry(window)
        usertitle = Label(window, text="---Username---", bg="#39d972")
        passtitle = Label(window, text="---Password---", bg="#39d972")
        message = Label(window, bg="#39d972")
        user = Entry(window)
        passw = Entry(window, show='*')
        passw_title = Label(window,text="---Retype-Password--", bg="#39d972")
        passw1 = Entry(window, show='*')
        go = Button(window, text="Add Account!", command = callback, bg="#93ff00")
        perm_title = Label(window,text="---Permission Level--", bg="#39d972")
        permission = Entry(window)


        title1.pack()
        profile_title.pack()
        profile.pack()
        usertitle.pack()
        user.pack()
        passtitle.pack()
        passw.pack()
        passw_title.pack()
        passw1.pack()
        perm_title.pack()
        permission.pack()
        go.pack()
        message.pack()
        window.mainloop()