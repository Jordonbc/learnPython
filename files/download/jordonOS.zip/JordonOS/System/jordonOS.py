from tkinter import *
import sys


global max_memory

max_memory=open("System/max_memory.txt","r").read()
max_memory = int(max_memory)
sys.setrecursionlimit(max_memory)
##########################################################################
# Login Redirect
def start():
    global user_account
    user_account = "jordonOS"
    filecheck = "false"
    systemfile = open("Cache/systemfile.file", "w")
    systemfile.write(filecheck)
    systemfile.close()
    import login
    from login import login_code

    login_code()

def error(Exception, description):
    err_root = Tk()
    err_root.title("JordonOS System Failure")
    err_root.geometry("500x400")
    err_root.configure(bg="#FF0000")
    root_window.destroy()

    text = Label(err_root, text="JORDONOS SYSTEM FAILURE", bg="#FF0000",font=("Default 18 bold"))
    text1 = Label(err_root,text=Exception, bg="#FF0000",font=("Default 14 bold"))
    text2 = Label(err_root,text=description, bg="#FF0000",font=("Default 14 bold"))

    text.pack()
    text1.pack()
    text2.pack()
    err_root.mainloop()
#################################################################################
# MENU INTERFACE SCRIPT
def interface():
    TMP = open("System/version","r").read()
    version = TMP
    from tkinter.filedialog import askopenfilename
    from tkinter.filedialog import asksaveasfilename
    import os
    import base64
    import getpass
    import sys
    import shutil

    sys.path.insert(0, "Games")
    sys.path.insert(0, "Applications")
    savefile = asksaveasfilename
    openfile = askopenfilename

    import text_craft

    debuglog = open("Cache/debuglog.log", "a")
    debuglog.write("\n")
    debuglog.write("DEBUG=IMPORTING JPAD")
    debuglog.write("\n")
    debuglog.close()
    import jpad
    from jpad import jpad_code

    debuglog = open("Cache/debuglog.log", "a")
    debuglog.write("\n")
    debuglog.write("DEBUG=IMPORTING SHUTDOWN")
    debuglog.write("\n")
    debuglog.close()
    import shutdown
    from shutdown import shutdown_code

    debuglog = open("Cache/debuglog.log", "a")
    debuglog.write("\n")
    debuglog.write("DEBUG=IMPORTING TIME")
    debuglog.write("\n")
    debuglog.close()
    import time

    print("\n")
    account = open("login.file", "r")
    user_account = account.read().replace("\n", "")
    user_account = int(user_account)
    nick = open("nick.file", "r")
    nick = nick.read().replace("\n", "")
    global permission
    permission = user_account
    import datetime

    today = datetime.date.today()
    user_machine = getpass.getuser()
    def switch_user():
        try:
            import login
            from login import login_code
            root_window.destroy()
            login_code()
        except:
            error("#00001","Error on importing and executing switch_user")

    def calc():
        if permission >= 1:
            try:
                import calculator
            except:
                error("#00002","Error on importing and executing calc")
        else:
            deny()
    def info():
        if permission >= 0:
            try:
                debuglog = open("Cache/debuglog.log", "a")
                debuglog.write("\n")
                debuglog.write("DEBUG=USER ENTERED=INFO")
                debuglog.write("\n")
                debuglog.close()
                time.sleep(1)
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                import info
                from info import info_code
                info_code()
            except:
                error("#00003","Error on importing and executing info")
        else:
            deny()
    def cal():
        try:
            if permission >= 1:
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                try:
                    import custom_apps
                    from custom_apps import cal
                    cal()
                except:
                    print("not working!!")
            else:
                deny()
        except:
            error("#00004","Error on importing and executing cal")
    def gui_jpad():
        try:
            if permission >= 1:
                time.sleep(1)
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                jpad_code()
            else:
                deny()
        except:
            error("#00005","Error on importing and executing gui_jpad")
    def fe():
        try:
            import file_explorer
            from file_explorer import file_explorer_code
            file_explorer_code()
        except:
            error("#00006","Error on importing and executing fe")

    def new_user():
        try:
            if permission >= 2:
                import newuser
                from newuser import newuser_code
                newuser_code()
            else:
                deny()
        except:
            error("#00007","Error on importing and executing new_user")
    def deny():
        try:
            root = Tk()
            root.title("JordonOS Access is Denied!")
            root.geometry("100x50")
            root.wm_iconbitmap("System/JordonOS Logo.ico")
            root.configure(bg="#FF0000")
            text = Label(root,text="Access is Denied!", bg="#FF0000")

            text.pack()
            root.mainloop()
        except:
            error("#00008","Error on executing deny")
    def update_checker():
        try:
            if permission >= 1:
                import updater
                from updater import update
                update()
            else:
                deny()
        except:
            error("#00009","Error on importing and executing update_checker")

    def chpass():
        try:
            from login import password
            from login import username
            from login import name
            from login import line
            def callback():
                oldpass = pass_entry1.get()
                newpass = pass_entry2.get()
                retypepass = pass_entry3.get()
                if oldpass == password and newpass == retypepass:
                    file = open("System/Users/" + name.lower() + "_profile.txt", "w")
                    file.write(line[0])
                    file.write(line[1])
                    file.write(retypepass)
                    file.write("\n")
                    file.write(line[3])
                    file.write(line[4])
                    message.configure(text="Password Changed!")
                    root.destroy()
                else:
                    message.configure(text="Err: verify failed!\nmake sure the password match!")
            root = Tk()
            root.title("JordonOS Change password!")
            root.geometry("350x250")
            root.wm_iconbitmap("System/JordonOS Logo.ico")
            root.configure(bg="#39d972")
            oldpass_title = Label(root,text="---Old-Password---", bg="#39d972")
            pass_entry1 = Entry(root, show='*')
            newpass_title = Label(root,text="---New-Password---", bg="#39d972")
            pass_entry2 = Entry(root, show='*')
            retype_pass = Label(root,text="---Retype-Password---", bg="#39d972")
            pass_entry3 = Entry(root, show='*')
            go = Button(root, text="Change Password!", command = callback, bg="#93ff00")
            message = Label(root, bg="#39d972")

            oldpass_title.pack()
            pass_entry1.pack()
            newpass_title.pack()
            pass_entry2.pack()
            retype_pass.pack()
            pass_entry3.pack()
            go.pack()
            message.pack()

            root.mainloop()
        except:
            error("#00010","Error on importing and executing chpass")

    def minesweeper():
        try:
            import minesweeper
            from minesweeper import mine_sweeper
            mine_sweeper()
        except:
            error("#00012","Error on importing and executing minesweeper")
    def play_music():
        import music_player
    def search_internet(self):
        import webbrowser
        webbrowser.open_new_tab("https://www.google.co.uk/#q="+searchvar.get())
    def memorycheck():
        root = Tk()
        root.title("JordonOS Memory Check")
        root.geometry("200x100")
        root.wm_iconbitmap("System/JordonOS Logo.ico")
        root.configure(bg="#39d972")
        max_memory=open("System/max_memory.txt","r").read()
        max_memory = int(max_memory)
        memory = 0
        type="B"
        global text

        text = Label(root,text="Max memory: " + str(memory)+ type, bg="#39d972")
    
        if max_memory >= 1000000 and max_memory < 1000000000:
            memory = max_memory/1000000
            memory = int(memory)
            type = "MB"
            text.configure(text="Max memory: " + str(memory)+ type)
        if max_memory >= 1000 and max_memory < 1000000:
            memory = max_memory/1000
            memory = int(memory)
            type = "KB"
            text.configure(text="Max memory: " + str(memory)+ type)
        else:
            type = "B"
            text.configure(text="Max memory: " + str(memory)+ type)

        text.pack()
        root.mainloop()
    ###################################
    #               Tkinter
    def dev_interface():
        global searchvar
        global main_menu
        from login import user_dir
        from login import username
        global root_window
        root_window = Tk()
        root_window.title("JordonOS      " + "Release Version: " + version + "      Username: " + nick)
        root_window.geometry("500x400")
        root_window.wm_iconbitmap("System/JordonOS Logo.ico")
        try:
            open(user_dir+"background.png")
            bg = 1
        except:
            bg = 0

        if bg == 1:
            canvas = Canvas(root_window, width=500, height=400)
            background_image = PhotoImage(file=user_dir+"background.png")
            canvas.create_image(0, 0, image=background_image, anchor=NW)
            canvas.pack(expand=YES, fill=BOTH)
        else:
            root_window.configure(bg="#39d972")

        root_window.configure(bg="#39d972")
        main_menu = Menu(root_window)
        root_window.config(menu=main_menu)
        start_menu = Menu(main_menu)

        main_menu.add_cascade(label="Start", menu=start_menu)
        start_menu.add_command(label="Check for updates", command=update_checker)
        start_menu.add_command(label="New User", command=new_user)
        start_menu.add_command(label="Change Password", command=chpass)
        start_menu.add_command(label="Logout", command=switch_user)
        start_menu.add_command(label="Exit", command=shutdown_code)

        program_menu = Menu(main_menu)
        main_menu.add_cascade(label="Programs", menu=program_menu)
        application_menu = Menu(program_menu)
        program_menu.add_cascade(label="Applications", menu=application_menu)
        application_menu.add_command(label="Calculator", command=calc)
        application_menu.add_command(label="JPAD", command=gui_jpad)
        application_menu.add_command(label="Custom App Launcher", command=cal)
        application_menu.add_command(label="Info", command=info)
        application_menu.add_command(label="Music Player (Experimental)", command=play_music)
        application_menu.add_command(label="Memory Check", command=memorycheck)

        game_menu = Menu(program_menu)
        program_menu.add_cascade(label="Games", menu=game_menu)
        game_menu.add_command(label="Minesweeper", command=minesweeper)

        f = []
        for (dirpath, dirnames, filenames) in os.walk("Users/"+username):
            f.extend(dirnames)
            break


        user_directory_menu = Menu(main_menu)
        main_menu.add_cascade(label=username, menu=user_directory_menu)
        user_directory_menu.add_command(label="File Explorer", command=fe)

        searchText = Label(root_window, text="Search for: ", bg="#39d972")
        searchvar = StringVar()
        searchvar.set("Search")
        search = Entry(root_window, textvariable=searchvar, bd=5, bg="#39d972")
        search.bind("<Return>", search_internet)

        searchText.pack()
        search.pack()

        root_window.mainloop()
    try:
        dev_interface()
    except:
        error("#00011","Error on executing dev_interface")
        ####################################
    print("DEV_PREVIEW: ",version)
    print("Hello,", nick, " the date is:", today, "and you are logged in as user: ", user_machine)
    print("\n")
    print("\n")
    print(
        "Enter 1 for Applications, 2 for info, 3 for logout, 4 for calculator, 5 for jpad, 6 for restart, 7 for System Tools or 8 to shutdown")
    user = input("// ")
    #   APPS
    if user == "1":
        debuglog = open("Cache/debuglog.log", "a")
        debuglog.write("\n")
        debuglog.write("DEBUG=USER ENTERED=INFO")
        debuglog.write("\n")
        debuglog.close()
        time.sleep(1)
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
        print("Type 1 for Info, 2 for Calculator, 3 Jpad, 4 for Custom App Launcher or 5 to cancel")
        user = input("// ")
        #   INFO
        if user == "1":
            if permission >= 0:
                debuglog = open("Cache/debuglog.log", "a")
                debuglog.write("\n")
                debuglog.write("DEBUG=USER ENTERED=INFO")
                debuglog.write("\n")
                debuglog.close()
                time.sleep(1)
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                import info
                from info import info_code

                info_code()
            else:
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                print("Access Denied!")
                time.sleep(1)
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                interface()
                #   CALCULATOR
        if user == "2":
            if permission >= 1:
                debuglog = open("Cache/debuglog.log", "a")
                debuglog.write("\n")
                debuglog.write("DEBUG=USER ENTERED=CALCULATOR")
                debuglog.write("\n")
                debuglog.close()
                time.sleep(1)
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                calculator_code()
            else:
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                print("Access Denied!")
                time.sleep(1)
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                interface()
                #   JPAD
        if user == "3":
            if permission >= 1:
                debuglog = open("Cache/debuglog.log", "a")
                debuglog.write("\n")
                debuglog.write("DEBUG=USER ENTERED=JPAD")
                debuglog.write("\n")
                debuglog.close()
                time.sleep(1)
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                jpad_code()
            else:
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                print("Access Denied!")
                time.sleep(1)
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                interface()
                #   CUSTOM APP LAUNCHER
        if user == "4":
            if permission >= 1:
                debuglog = open("Cache/debuglog.log", "a")
                debuglog.write("\n")
                debuglog.write("DEBUG=USER ENTERED=CAL")
                debuglog.write("\n")
                debuglog.close()
                time.sleep(1)
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                v = 0
                try:
                    import custom_apps
                    from custom_apps import cal
                    cal()
                    v = 1
                except:
                    print("not working!!")
                while v == 1:
                    import custom_apps
                    from custom_apps import cal
                    sys.path.insert(0,"Applications/cal_apps")
                    cal()
                    v = 0
            else:
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                print("Access Denied!")
                time.sleep(1)
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                interface()

    #   SYSTEM TOOLS
    if user == "7":
        if permission >= 2:
            debuglog = open("Cache/debuglog.log", "a")
            debuglog.write("\n")
            debuglog.write("DEBUG=USER ENTERED=SYSTEM-TOOLS")
            debuglog.write("\n")
            debuglog.close()
            time.sleep(1)
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            print("//SYSTEM-TOOLS\n")
            print("press 1 for FileCheck, 2 for Backup and Restore, 3 to update or 4 to exit")
            user = input("// ")
            if user == "1":
                filecheck = "true"
                systemfile = open("Cache/systemfile.file", "w")
                systemfile.write(filecheck)
                systemfile.close()
                print("FileCheck set, restart to take effect!")
                time.sleep(3)
                interface()
            if user == "2":
                import shutil
                ##############################################################################
                print("Copying System Files and Folders...")
                shutil.copytree("../JordonOS 2.0", "OS_Backup/", symlinks=False, ignore=None)
                print("Backup Complete!")
                time.sleep(3)
                interface()
            if user == "3":
                print("Error_Feature_not_Implemented")
                interface()
            if user == "4":
                interface()
            else:
                print("Error_Command_Unknown")
                interface()
        else:
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            print("Access Denied!")
            time.sleep(1)
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            interface()
    #   GAMES
    if user == "1":
        if permission >= 0:
            debuglog = open("Cache/debuglog.log", "a")
            debuglog.write("\n")
            debuglog.write("DEBUG=USER ENTERED=TEXT-CRAFT")
            debuglog.write("\n")
            debuglog.close()
            time.sleep(1)
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            print("type 1 for text-craft or 2 to exit")
            user = input("//Games//")
            if user == "1":
                import text_craft
                from text_craft import textcraft

                textcraft()
            if user == "2":
                print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
                interface()
        else:
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            print("Access Denied!")
            time.sleep(1)
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            interface()
    #   LOGOUT
    if user == "3":
        if permission >= 0:
            debuglog = open("Cache/debuglog.log", "a")
            debuglog.write("\n")
            debuglog.write("DEBUG=USER ENTERED=LOGOUT")
            debuglog.write("\n")
            debuglog.close()
            time.sleep(1)
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            import login
            from login import login_code

            login_code()
        else:
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            print("Access Denied!")
            time.sleep(1)
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            interface()

    #   RESTART
    if user == "6":
        if permission >= 0:
            debuglog = open("Cache/debuglog.log", "a")
            debuglog.write("\n")
            debuglog.write("DEBUG=USER ENTERED=RESTART")
            debuglog.write("\n")
            debuglog.close()
            print("JordonOS will now shutdown please wait...")
            time.sleep(5)
            print("Saving components...")
            time.sleep(5)
            print("shutting down...")
            print("\n\n")
            import startup
            from startup import startup_code

            startup_code()
        else:
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            print("Access Denied!")
            time.sleep(1)
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            interface()
    #   SHUTDOWN
    if user == "8":
        if permission >= 0:
            debuglog = open("Cache/debuglog.log", "a")
            debuglog.write("\n")
            debuglog.write("DEBUG=USER ENTERED=SHUTDOWN")
            debuglog.write("\n")
            debuglog.close()
            time.sleep(1)
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            shutdown_code()
        else:
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            print("Access Denied!")
            time.sleep(1)
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            interface()
    debuglog = open("Cache/debuglog.log", "a")
    debuglog.write("\n")
    debuglog.write("DEBUG=USER ENTERED=")
    debuglog.write(user)
    debuglog.write("\n")
    debuglog.close()
    time.sleep(3)
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")

    interface()
