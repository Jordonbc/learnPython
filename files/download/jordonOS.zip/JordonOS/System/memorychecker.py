import sys
from tkinter import *
global max_memory

max_memory=open("max_memory.txt","r").read()
max_memory = int(max_memory)
sys.setrecursionlimit(max_memory)

root = Tk()
root.title("JordonOS Memory Check")
root.geometry("200x100")
#root.wm_iconbitmap("System/JordonOS Logo.ico")
root.configure(bg="#39d972")
max_memory=open("max_memory.txt","r").read()
max_memory = int(max_memory)
memory = 0
type="B"
global text

text = Label(root,text="Max memory: " + str(memory)+ type, bg="#39d972")
    
if max_memory > 1000000 and max_memory < 9000000:
    memory = max_memory/1000000
    memory = int(memory)
    type = "MB"
    text.configure(text="Max memory: " + str(memory)+ type)
if max_memory >= 1000 and max_memory < 1000000:
    memory = max_memory/1000
    memory = int(memory)
    type = "KB"
    text.configure(text="Max memory: " + str(memory)+ type)
else:
    type = "B"
    text.configure(text="Max memory: " + str(memory)+ type)

text.pack()
root.mainloop()
