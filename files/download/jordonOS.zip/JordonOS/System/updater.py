from tkinter import *
import zipfile
from zipfile import *
import os
import urllib
import urllib.request
def update():
    def update_true():
        downzip = urllib.request.urlopen('http://fs.frederickgent.derbyshire.sch.uk/st10.jbrooks/JordonOS/update/jordonOS.zip').read()
        with open('../update.zip', 'b+w') as f:
            f.write(downzip)
        def unzip(source_filename, dest_dir):
            with zipfile.ZipFile(source_filename) as zf:
                for member in zf.infolist():
                    words = member.filename.split('/')
                    path = dest_dir
                    for word in words[:-1]:
                        drive, word = os.path.splitdrive(word)
                        head, word = os.path.split(word)
                        if word in (os.curdir, os.pardir, ''): continue
                        path = os.path.join(path, word)
                    zf.extract(member, path)
        unzip("../update.zip","../")
        text.configure(text="Update Complete!")
        root.destroy()
    root = Tk()
    root.title("JordonOS Update")
    root.geometry("250x150")
    root.wm_iconbitmap("System/JordonOS Logo.ico")
    root.configure(bg="#39d972")
    text = Label(root, text="text", bg="#39d972", font=("14"))
    update_button = Button(root, text="Update Now!", command=update_true, bg="#93ff00")


    g = urllib.request.urlopen('http://fs.frederickgent.derbyshire.sch.uk/st10.jbrooks/JordonOS/update/upversion.txt').read()
    with open('System/update', 'b+w') as f:
        f.write(g)
    cversion = open("System/version", "r").read()
    cversion = float(cversion)
    g = open("System/update","r")
    g = g.readlines()
    file = str(g[0]).replace("b","").replace("'", "")
    file = float(file)
    print(file)
    print(cversion)
    if cversion < file:
        text.configure(text="A new update is available!")
        update_button.pack(side=BOTTOM)
    else:
        text.configure(text="You are using the latest version!")

    text.pack()
    root.mainloop()
