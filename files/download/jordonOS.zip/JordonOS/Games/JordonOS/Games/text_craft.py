#text-craft.py
def textcraft():
	global user
	import time
	win="You win!"
	build_house="do you want to build a house: y/n "
	night="it becomes night"
	spawn="You spawn in a world with lots of trees what do you do..."
	enough_wood="you have enough wood to build a house: "
	morning="it becomes morning"
	diamond="you find a nice shiny diamond!"
	mountain="you see a tall mountain what would you like to do?"
	mountain_1="you start to dig in to the mountain and you realize\nthat it is hollow and creepers start spawning in side the mountain"
	mountain_2="you walk around it and spot an abandoned mine"
	mountain_3="you start climbing it and you see that it isn't just a mountain it is also a volcano and teh ground starts to shake, then the volcano erupts..."
	def quest1():
		print(spawn)
		user=input("1 = chop all trees, 2 = chop down 10 trees or 3 to do nothing: ")
		if user=="1":
			print(night)
			time.sleep(5)
			state1()

		if user=="2":
			print(night)
			time.sleep(5)
			state1()
		if user=="3":
			print(night)
			time.sleep(5)
			creeper_death()
	def creeper_death():
		print("a creeper starts moving towards you")
		time.sleep(5)
		print("the creeper explodes next to you...")
		time.sleep(5)
		print("You Died")
		time.sleep(5)
	def death():
		print("You Died!")
		time.sleep(5)
	

	def state1():
		print(enough_wood)
		user=input(build_house)
		if user=="n":
			creeper_death()
		if user=="y":
			print(morning)
			state2()
	def state2():
		time.sleep(5)
		print(mountain)
		user=input("type 1 to dig in to the mountain, 2 to walk around the mountain or 3 to climb it: ")
		if user=="1":
			print(mountain_1)
			time.sleep(5)
			creeper_death()
		if user=="2":
			print(mountain_2)
			time.sleep(5)
			print(diamond)
			print(win)
		if user=="3":
			print(mountain_3)
			time.sleep(5)
			death()

	quest1()