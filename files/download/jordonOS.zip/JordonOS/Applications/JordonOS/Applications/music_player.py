from tkinter import *
from tkinter.filedialog import *
import mp3play
import time

def music():
    root = Tk()
    def openfile():
        global file
        file = askopenfilename(defaultextension=".mp3", filetypes=[('MP3 file', '*.mp3')])

    def playfile():
        clip = mp3play.load(file)
        clip.play()
        time.sleep(clip.seconds())
        mp3play.volume(clip)
        clip.stop()
    root.configure(bg="#39d972", bd=5)

    openbutton = Button(root,text="Open", command=openfile, bg="#39d972", bd=5)
    openbutton.pack(side=LEFT)

    playbutton = Button(root,text="Play", command=playfile, bg="#39d972", bd=5)
    playbutton.pack(side=LEFT)

    root.mainloop()
music()