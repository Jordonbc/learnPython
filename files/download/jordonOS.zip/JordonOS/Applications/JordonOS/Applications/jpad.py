from tkinter import *
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import asksaveasfilename
from login import user_dir
def jpad_code():
    version = "1.2.0"


    root = Tk()
    root.title("Jpad Text Editor")
    root.geometry("500x400")
    root.wm_iconbitmap("System/JordonOS Logo.ico")

    textPad = Entry(root, justify=LEFT)

    # create a menu & define functions for each menu item

    def open_command():
        file = askopenfilename(defaultextension=".txt", filetypes=[('Text Document','*.txt'), ('All files','*.*')], initialdir = user_dir)
        root.title("Jpad Text Editor"+"     File: "+ file)
        file = open(file, "r")
        if file != None:
            contents = file.read()
            textPad.delete(0, END)
            textPad.insert(0, contents)
            file.close()

    def save_command():
        file = asksaveasfilename(defaultextension=".txt", filetypes=[('Text Document','*.txt'), ('All files','*.*')], initialdir = user_dir)
        root.title("Jpad Text Editor"+"     File: "+ file)
        file = open(file,"w")
        if file != None:
            # slice off the last character from get, as an extra return is added
            data = textPad.get()
            file.write(data)
            file.close()

    def exit_command():
        root.destroy()

    def about_command():
        msbox=Tk()
        msbox.title("Jpad About")
        msbox.geometry("150x80")
        label = Label(msbox, text="Jpad\nJordonOS Text Editor\n\nVersion: "+version)
        label.pack()
        msbox.mainloop()


    def new():
        root.title("Jpad Text Editor"+"     File: NEW FILE")
        textPad.delete(0, END)
    menu = Menu(root)
    root.config(menu=menu)
    filemenu = Menu(menu)
    menu.add_cascade(label="File", menu=filemenu)
    filemenu.add_command(label="New", command=new)
    filemenu.add_command(label="Open...", command=open_command)
    filemenu.add_command(label="Save", command=save_command)
    filemenu.add_separator()
    filemenu.add_command(label="Exit", command=exit_command)
    helpmenu = Menu(menu)
    menu.add_cascade(label="Help", menu=helpmenu)
    helpmenu.add_command(label="About...", command=about_command)

    #
    textPad.pack(fill=BOTH, expand=YES)
    textPad.pack(fill=BOTH, expand=YES)
    root.mainloop()
