# Custom App Launcher
__author__ = 'Jordon'
from tkinter import *
from tkinter.filedialog import askopenfilename
import sys
sys.path.insert(0,"cal_apps")
import importlib
import importlib.machinery
import os
import tkinter.messagebox
import time
def cal():
    root = Tk()
    root.title("JordonOS Custom App Launcher")
    root.geometry("550x50")
    root.configure(bg="#39d972")

    def openfile():
        global userfile
        user = askopenfilename(defaultextension=".py", filetypes=[('Python', '*.py'), ('Python Executable', '*.pyw'),
                                                                  ("Executable", "*.exe")],
                               initialdir="Applications/cal_apps")
        userfile = user
        mystring.set(userfile)

    def run():
        try:
            loader = importlib.machinery.SourceFileLoader(name.get(),filepath.get())
            foo = loader.load_module()
        except:
            try:
                if " " in userfile:
                    tkinter.messagebox._show("Error","the file path cannot have spaces!")
                else:
                    os.system(userfile)
            except:
                print("Critical: No Module Name","'",name.get(),"'")

    global mystring
    mystring = StringVar()
    name_title = Label(root, text="Name:", bg="#39d972", bd=10, font=("Default 14 bold"))
    name = Entry(root, bg="#39d972", bd=10,)
    path = Label(root,text="File:", bg="#39d972", bd=10, font=("Default 14 bold"))
    filepath = Entry(root, textvariable=mystring, bg="#39d972", bd=10)
    go = Button(root,text="Execute", bg="#39d972",bd=10, command=run)
    ask = Button(root, text="Open", bg="#39d972", bd=10, command=openfile)

    go.pack(side=RIGHT)
    ask.pack(side=RIGHT)

    name_title.pack(side=LEFT)
    name.pack(side=LEFT)
    path.pack(side=LEFT)
    filepath.pack(side=LEFT)

    root.mainloop()
