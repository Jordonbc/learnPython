from tkinter import *
def info_code():
    root = Tk()
    root.title("JordonOS Info")
    root.geometry("550x80")
    root.configure(bg="#39d972")

    text1 = Label(root,text="This is JordonOS.", bg="#39d972")
    text2 = Label(root,text="JordonOS is an operating system made by Jordon Brooks and developed as a project called JordonOS.", bg="#39d972")
    text3 = Label(root,text="JordonOS is for education use only.", bg="#39d972")
    text4 = Label(root,text="jordonOS currently uses 643+ lines of code.", bg="#39d972")

    text1.pack()
    text2.pack()
    text3.pack()
    text4.pack()
    root.mainloop()