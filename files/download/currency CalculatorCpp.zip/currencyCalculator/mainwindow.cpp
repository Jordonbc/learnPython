#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <string>
#include <iostream>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    float tmp = ui->lineEdit->text().toFloat();

    if (ui->comboBox->currentIndex() == 0)
    {
        if (ui->comboBox_2->currentIndex() == 0)
        {
            ui->lineEdit_2->setText(QString::number(tmp));
        }
        else if (ui->comboBox_2->currentIndex() == 1)
        {
            ui->lineEdit_2->setText(QString::number(tmp*1.14));
        }
        else if (ui->comboBox_2->currentIndex() == 2)
        {
            ui->lineEdit_2->setText(QString::number(tmp*0.78));
        }
    }
    else if (ui->comboBox->currentIndex() == 1)
    {
        if (ui->comboBox_2->currentIndex() == 0)
        {
            ui->lineEdit_2->setText(QString::number(tmp*0.88));
        }
        else if (ui->comboBox_2->currentIndex() == 1)
        {
            ui->lineEdit_2->setText(QString::number(tmp));
        }
        else if (ui->comboBox_2->currentIndex() == 2)
        {
            ui->lineEdit_2->setText(QString::number(tmp*0.69));
        }
    }
    else if (ui->comboBox->currentIndex() == 2)
    {
        if (ui->comboBox_2->currentIndex() == 0)
        {
            ui->lineEdit_2->setText(QString::number(tmp*1.28));
        }
        else if (ui->comboBox_2->currentIndex() == 1)
        {
            ui->lineEdit_2->setText(QString::number(tmp*1.45));
        }
        else if (ui->comboBox_2->currentIndex() == 2)
        {
            ui->lineEdit_2->setText(QString::number(tmp));
        }
    }
}
