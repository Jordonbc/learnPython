__author__ = 'Jordon'
from tkinter import *

global screenWidth
global screenHeight


def TempWindow():
    global screenWidth
    global screenHeight
    tempWindow = Tk()
    screenWidth = tempWindow.winfo_screenmmwidth()
    screenHeight = tempWindow.winfo_screenheight()
    tempWindow.destroy()


def CurrencyCalculator():
    global screenWidth
    global screenHeight
    window = Tk()
    window.geometry("400x200+" + str(int(screenWidth / 2)) + "+" + str(int(screenHeight / 2)))
    window.title("Python Currency Converter")

    title = Label(window, text="Currency Converter", font=("Arial", 20, "bold"))
    title.pack(side=TOP, fill=X)

    numTitle = Label(window, text="Input Number")
    numInput = Entry(window)

    numTitle.pack()
    numInput.pack()

    rateTitle = Label(window, text="Rate")
    rateInput = Entry(window)

    rateTitle.pack()
    rateInput.pack()

    def calculate():
        global p
        p = 0
        def validate():
            global p
            try:
                float(numInput.get())
                float(rateInput.get())
                p = 1
            except:
                answerText.configure(text="Error: Check Input!")
                p = 0
        validate()
        number = float(numInput.get())
        rate = float(rateInput.get())

        if p == 1:
            answer = str("£") + str(float(number * rate))[:4]
            answerText.configure(text=answer)
        else:
            pass

    calculateButton = Button(window, text="Calculate", command=calculate)
    calculateButton.pack()

    answerText = Label(window, text="£0", font=("Arial", 16, "bold"))
    answerText.pack()

    window.mainloop()


TempWindow()
CurrencyCalculator()
